import StatsCards from "../components/StatCards";
import '@fortawesome/fontawesome-svg-core/styles.css';
import { config } from '@fortawesome/fontawesome-svg-core';
import Image from "next/image";

export default function Home() {
  return (
    <>
            <StatsCards/>
    
    </>
  );
}