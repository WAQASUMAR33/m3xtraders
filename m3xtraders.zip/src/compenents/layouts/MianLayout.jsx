import React from "react";

function MainLayout() {
  return <div>MainLayout</div>;
}

export default MainLayout;